using System;
using System.Linq;
using System.Linq.Expressions;

namespace lesson3.Filtering
{
    public class Filter
    {
        public int Kind { get; set; }
        public string Attr { get; set; }
        public Object Value { get; set; }
        public Filter F1 { get; set; }
        public Filter F2 { get; set; }
    }


    public static class FilterUtility<T>
    {
        public static Expression<Func<T, bool>> FilterToExpression(Filter f)
        {
            // type of the involved entity in our case Actor
            var type = typeof(T);
            var parameter = Expression.Parameter(type, "p");

            return FilterToExpressionAux(f, parameter);
            // p => p.Title == "Star Wars"

        }

        public static Expression<Func<T, bool>> FilterToExpressionAux(Filter f, ParameterExpression p)
        {
            switch (f.Kind)
            {
                case 0:
                    {
                        // p.Title 
                        var property = Expression.Property(p, f.Attr);
                        //  "Starr Wars" 
                        var constant = Expression.Constant(f.Value);
                        // p => p.Title == "Starr Wars" 
                        var r = Expression.Lambda<Func<T, bool>>(Expression.Equal(property, constant), p);
                        Console.WriteLine(r);
                        return r;
                    }
                case 1:
                    {
                        Expression<Func<T, bool>> expr1 = FilterToExpressionAux(f.F1, p);
                        Expression<Func<T, bool>> expr2 = FilterToExpressionAux(f.F2, p);
                        // p.Title == "Starr Wars" && p.Release == "2019-1-1"
                        var body = Expression.And(expr1.Body, expr2.Body);
                        // p => p.Title == "Starr Wars" && p.Release == "2019-1-1"
                        var r = Expression.Lambda<Func<T, bool>>(body, p);
                        Console.WriteLine(r);
                        return r;
                    }
                case 2:
                    {
                        Expression<Func<T, bool>> expr1 = FilterToExpressionAux(f.F1, p);
                        Expression<Func<T, bool>> expr2 = FilterToExpressionAux(f.F2, p);
                        //p.Title == "Starr Wars" || p.Release == "2019-1-1"
                        var body = Expression.Or(expr1.Body, expr2.Body);
                        var r = Expression.Lambda<Func<T, bool>>(body, p);
                        Console.WriteLine(r);
                        return r;
                    }
                default: return null;
            }
        }
    }
}