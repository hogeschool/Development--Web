import * as ReactDOM from 'react-dom'
import { hello_world } from './components/hello'
import {App} from './main'



export let main = () => ReactDOM.render(App(), document.getElementById("react-content")) 