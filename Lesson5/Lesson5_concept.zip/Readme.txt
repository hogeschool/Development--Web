This is an empty template for a react application. To run the application you need to follow these steps: 

- In the command line navigate to client-app folder and run the following command "nom install". This will download all the dependencies declared in the package.json, which is located in that folder. Finger crossed that there are no broken dependencies on your machine! 

- If you receive any error you should first check if you have the latest version of Node.js.   

- Navigate back to the root directory of the project where you can find the .csproj file and run the command "dotnet run". Now the project will be compiled and the webserver will start to run. 

- Open the browser and enter the url given by the webserver in the command line. This is typically "http://localhost:5001/". If you encounter any errors in the command line regarding the SSL certification. You need to update the ssl certification (read the practice document of lesson 3)  

- You should now be able to see an empty React website. You might receive a warning about accepting the ssl certification. You should proceed and add exception in the browser.  