using System.Linq;
using System;
namespace lesson3.Pagination{
public class Page<T>{
    public int Index{get;set;}
    public int TotalPages{get;set;}
    public T[] Items{get;set;}
}

public static class Pagination{
    public static Page<T> GetPaged<T>(this Microsoft.EntityFrameworkCore.DbSet<T> l,int index, int page_size, Func<T, Object> order_selector) where T: class
    {
        var result = l.OrderBy(order_selector)
                    .Skip(index*page_size)
                    .Take(page_size)
                    .ToArray();
        
        // Missing code to address the issues: there is no result and item number is smaller than given page_size

        var totalItems = l.Count();
        var totalPages = totalItems / page_size;

        return new Page<T>{
            Index = index, 
            TotalPages  = totalPages ,
            Items = result
        };

    }
}

}