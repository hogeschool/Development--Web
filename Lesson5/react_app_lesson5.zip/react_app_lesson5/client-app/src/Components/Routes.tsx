import * as React from 'react';
import { Route } from 'react-router-dom';
import { Layout } from './Layout';
import { MoviesContainer } from './MoviesContainer';


export const routes = <Layout>
    <Route exact path='/'  />
    <Route path='/Movies' component={ MoviesContainer } />

</Layout>;
