import React from 'react';
import logo from './logo.svg';
import './App.css';
import * as RoutesModule from './Components/Routes';
import { BrowserRouter } from 'react-router-dom';
import { AppContainer } from 'react-hot-loader';

let routes = RoutesModule.routes;
const baseUrl = document.getElementsByTagName('base')[0].getAttribute('href')!;

const App: React.FC = () => {
  return (
    <AppContainer>
      <BrowserRouter children={routes} basename={baseUrl} />
    </AppContainer>
  );
}

export default App;
