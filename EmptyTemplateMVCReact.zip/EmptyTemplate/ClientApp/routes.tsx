import * as React from 'react';
import { Route } from 'react-router-dom';
import { Layout } from './components/Layout';

export const routes = <Layout>
    <Route exact path='/'  />
</Layout>;
