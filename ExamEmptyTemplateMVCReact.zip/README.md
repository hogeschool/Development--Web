* To setup the application run the following commands in the console inside the main folder of this application:
    - dotnet restore  #It might give you a warning, but that should not be a problem 
    - npm install    #It will download all the dependecies, but it might give you some warnings

* To run the application run the following commands in the console inside the main folder of this application:
    - .node_modules/.bin/webpack -w #You could use also this command instead: "npm run fe" which will run the same command
    - dotnet run

To see the application type localhost:5000 in a browser of your choice!

Good luck!