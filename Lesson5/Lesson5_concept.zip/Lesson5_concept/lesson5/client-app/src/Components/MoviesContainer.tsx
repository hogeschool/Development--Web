import * as React from "react";
import { RouteComponentProps } from "react-router";
import { Movie } from './Models/Models';

type MovieState = {};


export class MoviesContainer extends React.Component<RouteComponentProps<{}>, MovieState> {
    constructor(props: RouteComponentProps) {
        super(props);
    }

    componentWillMount(): void {
    }

    public render(): JSX.Element {
        return (
            <div>
                <h1>Movie</h1>
                <p>This component demonstrates fetching data from the server</p>
                {}
            </div>
        );
    }
}
