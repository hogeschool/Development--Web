import * as React from 'react'
import { RouteComponentProps } from "react-router";

export type HelloWorldState = {}
export type HelloWorldProps = {}

export class HelloWorld extends React.Component<RouteComponentProps<HelloWorldProps>, HelloWorldState> {
    constructor(props : HelloWorldProps){
        super(props)
        this.state = { }
    }
    public render() {
      return <h1>Hallo, <HelloWorldInner name={"Mark"}/></h1>;
    }
}


export type HelloWorldInnerState = {}
export type HelloWorldInnerProps = { name:string }

export class HelloWorldInner extends React.Component<RouteComponentProps<HelloWorldProps>, HelloWorldState> {
  constructor(props : HelloWorldProps){
      super(props)
      this.state = { }
  }
  public render() {
    return <p>{this.props.name}</p>
  }
}