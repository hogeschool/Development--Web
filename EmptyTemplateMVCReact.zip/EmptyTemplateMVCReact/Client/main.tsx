import * as React from 'react';

import { BrowserRouter } from 'react-router-dom';
import { routes } from './components/routes';


export const App = () : JSX.Element => {
  debugger
  return <BrowserRouter children={routes} />
}

