import * as React from 'react'

export const hello_world =
    <div className="container">
        <div className="row">
        <div className="col-md-12">
            <h1 className="text-center">Hello World</h1>
        </div>
        </div>
    </div>