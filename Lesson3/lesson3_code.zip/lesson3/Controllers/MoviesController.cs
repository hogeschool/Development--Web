using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using lesson3.Model;
using System.Linq.Expressions;
using lesson3.Filtering;

namespace lesson3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MoviesController : ControllerBase
    {
        private readonly MovieDbContext _context;

        public MoviesController (MovieDbContext context){
            this._context = context;
        }
        // GET api/movies
        [HttpGet]
        public ActionResult<IEnumerable<Movie>> Get()
        {   
            var movies = from m in _context.Movies select m;
            return Ok(movies);
        }

        [HttpGet("filter")]
        public ActionResult<IEnumerable<Movie>> Get([FromBody] Filter f)
        {   
            Expression<Func<Movie, bool>> expr = FilterUtility<Movie>.FilterToExpression(f);
            var movies = _context.Movies.Where(expr).Select(m => m);
            return Ok(movies);
        }


        // GET api/movies/5
        [HttpGet("{id}")]
        public ActionResult<Movie> Get(int id)
        {
            // var movie = from m in _context.Movies
            //             where m.Id == id
            //             select m;

            // var movie = _context.Movies.Find(id);
            var movie = _context.Movies.FirstOrDefault( m => m.Id == id );
            if(movie == null){
                return NotFound();
            }
            return Ok(movie);
        }

        // POST api/movies
        [HttpPost]
        public void Post([FromBody] Movie movie)
        {
        }

        // PUT api/movies/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] Movie movie)
        {
        }

        // DELETE api/movies/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
