using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using lesson3.Model;
using lesson3.Pagination;

namespace lesson3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ActorsController : ControllerBase
    {
        private readonly MovieDbContext _context;

        public ActorsController (MovieDbContext context){
            this._context = context;
        }
        // GET api/actors
        [HttpGet]
        public ActionResult<IEnumerable<Actor>> Get()
        {   
            var actors = from a in _context.Actors select a;
            return Ok(actors);
        }

         // GET api/actors/getactorspaged/{index}/{page_size}
        [HttpGet("getactorspaged/{index}/{page_size}")]
        public ActionResult<IEnumerable<Actor>> GetPaged(int index, int page_size)
        {   
            var actors = _context.Actors.GetPaged(index, page_size, a => a.Id);
            return Ok(actors);
        }

        // GET api/actors/5
        [HttpGet("{id}")]
        public ActionResult<Actor> Get(int id)
        {
          
            return Ok();
        }

        // POST api/actors
        [HttpPost]
        public void Post([FromBody] Actor actor)
        {
        }

        // PUT api/actors/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] Actor actor)
        {
        }

        // DELETE api/actors/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
