import * as React from "react";
import { RouteComponentProps } from "react-router";
import * as Models from "./Models/Models";
import * as Immutable from "immutable";

//Movies container
type Movie = Models.Movie;
type MovieState = { movieList: Immutable.List<Movie> | "Loading"};

export class MoviesContainer extends React.Component<RouteComponentProps<{}>, MovieState> {
    constructor(props: RouteComponentProps) {
        super(props);
        this.state = { movieList: "Loading" };
        this.loadMovies().then(data => { this.setState({ ...this.state, movieList: Immutable.List<Movie>(data) }); })
        .catch(error =>  console.log(error));
    }


    private loadMovies = async function (): Promise<Immutable.List<Movie>> {
        let res: Response = await fetch("./api/movies", {
            method: "get",
            body: null,
            headers: { "content-type": "application/json" }
        });
        let movies: Promise<Immutable.List<Movie>> = await res.json();
        return movies;
    };

    private renderMoviesTable(ml: Immutable.List<Movie>): JSX.Element {
        return (
            <table className="table">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Release</th>
                    </tr>
                </thead>
                <tbody>
                    {ml.map((m: Movie ) => (<MovieRow key={m.id} movie={m} />))}
                </tbody>
            </table>
        );
    }

    public render(): JSX.Element {
        let contents = this.state.movieList == "Loading" ? (<p><em>Loading...</em></p>)
            : (this.renderMoviesTable(this.state.movieList));
        return (
            <div>
                <h1>Movie</h1>
                <p>This component demonstrates fetching data from the server.</p>
                {contents}
            </div>
        );
    }
}


//Movie row
type MovieRProps = { movie: Movie };
type MovieRState = {  };
class MovieRow extends React.Component<MovieRProps, MovieRState> {
    constructor(props: MovieRProps) {
        super(props);
    }

    render(): JSX.Element {
        let movie = this.props.movie;
        return (
            <tr key={movie.id}>
                <td>{movie.title}</td>
                <td>{movie.release}</td>
            </tr>
        );
    }
}