import * as Immutable from "immutable";
export type Movie = {
    id: number,
    title: string,
    release: Date
    actors: Actor[]
};
export type Actor = {
    id: number,
    name: string,
    gender: "male" | "female",
    birth: Date,
    movieid: number
};
