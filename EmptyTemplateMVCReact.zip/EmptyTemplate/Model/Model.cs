using Microsoft.EntityFrameworkCore;
using System;

namespace reactTest.Model{
public class DBContext : DbContext{
    public DBContext(DbContextOptions<DBContext> options): base(options)
    { }
    }
}