import * as ReactDOM from 'react-dom'
import { hello_world } from './components/hello'

export let main = () => ReactDOM.render(hello_world, document.getElementById("react-content")) 