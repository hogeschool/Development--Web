using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System;
using Microsoft.Extensions.Logging;

namespace lesson6.Model{
    public class MovieDbContext : DbContext{
        public DbSet<Movie> Movies{get; set;} 
        public DbSet<Actor> Actors{get; set;} 

        public MovieDbContext (DbContextOptions option) : base(option){}
        // protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder){
            // optionsBuilder.UseSqlite("Data Source=Movie.db");
            // optionsBuilder.UseNpgsql(
            // "UserID=postgres;Password=postgres;Host=localhost;Port=5432;Database=MovieDB;Pooling=true;");
           
           //activate logging for compiled queries 
            // var lf = new LoggerFactory();
            // lf.AddProvider(new MyLoggerProvider());
            // optionsBuilder.UseLoggerFactory(lf);

        // }

        protected override void OnModelCreating(ModelBuilder mb){
            mb.Entity<Movie>()
            .HasKey( m => m.Id);
            mb.Entity<Actor>()
            .HasKey(a => a.Id);
            mb.Entity<Actor>()
            .HasOne( a => a.Movie)
            .WithMany(a => a.Actors)
            .HasForeignKey(a => a.MovieId);
        }

    }

    public class Movie{
        public int Id{get;set;}
        public string Title{get;set;}
        public DateTime Release {get;set;}
        public List<Actor> Actors{get;set;}

    }
    public class Actor{
        public int Id{get;set;}
        public string Name{get;set;}
        public string Gender{get;set;}
        public DateTime Birth{get;set;}
        public int MovieId{get;set;}
        public Movie Movie{get;set;}

    }




}