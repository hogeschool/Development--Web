import * as React from 'react';
import { Route } from 'react-router-dom';
import { Layout } from './Layout';
import { hello_world } from './hello';
import { HelloWorld } from './hello_component';

export const routes = <Layout>
    <Route exact path='/'component={ HelloWorld } />
    <Route path='/test1' render={() => hello_world } />
    <Route path='/test2' render={() => <div>Hello World! (inline render)</div>} />
</Layout>;
